# ChoiceLoop integration handoff

ChoiceLoop is a private, skills-only ChatGPT plugin. Its skills are reusable instructions, not HTTP endpoints. This bundle does not create a Site, MCP server, database, scheduled worker, search adapter or publishing integration.

## Files

- `choiceloop_contract.json`: versioned Draft 2020-12 schemas, metric rules, compatibility migrations and semantic safety requirements.
- `role_instructions/`: portable English instructions for all five specialist roles and orchestration. Read supporting references when the instructions point to them.
- `brain_spec.json`: state machine, input/output rules, frozen evaluation rubric, holdout policy and approval gates.
- `integration_manifest.json`: actual plugin ID and release evidence, capability availability, unverified installation state, missing integrations and SHA-256 file inventory.
- `input_originals/`: byte-preserved source inputs. Original Japanese preparation notes are source material, not new English demo output.
- `example_fixtures/`: isolated `ILLUSTRATIVE_SAMPLE` data. These are software examples, never live measurements.
- `prepared_import/`: an explicit import/checkpoint of the attached data; the 24-case plan remains proposed, the live dataset remains empty, and no live baseline is claimed.
- `runtime/`: optional local JSON import/export and checkpoint runner. Python is not an HTTP service. Full JSON Schema validation uses the separately installed `jsonschema` Python package; do not replace an unavailable validator with a claim of validation.
- `validation/`: tests actually executed, known pending integration tests and input-migration audit.

## How an app builder should use this bundle

1. Load each contract schema as data and validate imported records. Maintain the original observation fields. Apply only documented versioned extensions/migrations and retain the original bytes and their hashes.
2. Implement the state machine in the app's own backend, or offer explicit JSON import/export if no backend exists. Do not advertise a skill name as an API route. A future model call must load the relevant portable instructions into its actual evaluation context.
3. Keep neutral Discovery separate from Analysis. A fresh search context receives only the exact original query and recorded platform/session settings. Do not attach ChoiceLoop instructions, target hints, candidates, diagnoses, treatments or holdout results. If isolation cannot be verified, retain the run as target-conditioned/unverified and exclude it from neutral benchmark KPIs. Use the manual handoff instead of silently using this project chat.
4. Keep `PUBLIC_SOURCE_AUDIT` in the evidence registry. Do not promote a site audit or illustrative record to a live observation. Keep failed and partial search attempts with exclusion reasons. Calculate mention and recommendation rates separately, with numerators, denominators, distinct questions, repeats, errors and unknowns.
5. Require explicit plan freezing before research. The attached `parallel-v2` plan is only proposed, despite the wording of its original status. Use 12 development and 12 validation questions. A diagnosis/optimizer payload must contain development scenarios/results only. Original seed splits and weights remain historical data.
6. Keep baseline records immutable and append new run IDs. Freeze candidate set, evidence, exact scenarios, rubric, prompt and recorded model/settings for a controlled comparison. Give each arm a fresh context, blind the arm labels and include unchanged controls. Packets prepared for an evaluator are not executed results. An unchanged presentation can still vary under an AI evaluator; expose control failures and missing evidence rather than force an uplift.
7. Freeze the exact asset before final holdout evaluation. Track validation access/consumption. If holdout results influence another optimization, choose a new holdout and stop calling the exposed set untouched validation.
8. Present one or two focused drafts with claim-level source IDs. A source statement must support the target claim. Owner-confirmation needs and contradictory happy-hour wording remain unresolved; do not publish a definitive schedule from the legacy draft. JSON-LD must reflect verified, visible content and cannot promise recommendation eligibility or ranking changes.
9. Bind approval to intervention ID, asset version, exact content hash, action and destination. `export`, `simulation` and `publish` are separate authorizations. The current package has no publishing implementation. Never submit reservations, hold inventory, enter personal details, send messages or make payments.
10. When persistence, search or publishing tools are added later, discover their actual authenticated schemas and permissions first. Map the contract to those schemas explicitly. Verify writes/readbacks before claiming database storage, cross-chat persistence or external publication. Keep user/workspace ownership and the private plugin ID unchanged.

## Local setup and initial commands

Python 3 runs the local helper. Install the JSON Schema validator in your chosen environment when you need full schema checks:

```bash
python3 -m pip install jsonschema
python3 runtime/choice_loop_v2.py --help
python3 runtime/choice_loop_v2.py prepare --inputs input_originals --out choice-loop-run
python3 runtime/choice_loop_v2.py smoke --workspace choice-loop-run
python3 runtime/choice_loop_v2.py metrics --workspace choice-loop-run
```

Read current command help before invoking commands. `prepare` preserves the source files and leaves the plan proposed. `smoke` creates a three-question manual handoff and does not execute a search. Plan freezing requires a separate explicit acknowledgement of the imported plan hash. No approval is inferred from elapsed time or a missing answer.

For genuine imported live observations, retain raw answers, exact query bytes/hash, dates, platform/session metadata and sources. A visible model label may be recorded; an unknown backend/model version stays null with a reason. Unknown facts are not zeros. A numbered restaurant list is display order unless the captured answer establishes explicit preference ranking.

## Live retests and claims

Without verified public implementation, a live retest measures repeatability only. It cannot show that an unpublished draft changed public visibility. Even after an approved publication, uncontrolled index changes, model changes, location, account context and sampling variability remain. Expose those differences; do not claim perfect reproducibility or causal proof.

Controlled simulated choices are separate from live visibility. They are not actual customers, bookings, conversion, revenue or proof of human psychology. The 24 synthetic cases provide coverage, not a representative customer sample.

## Verification boundary

The manifest and validation report distinguish executed local tests from pending live integrations. A saved plugin release is not by itself proof of installation or a working external adapter. Six skills being available in a chat establishes that availability only. Import/export checkpoint files do not establish a database or automatic cross-chat memory.
