import { sqliteTable, text, integer, primaryKey } from 'drizzle-orm/sqlite-core';

// An owner-scoped, revisioned aggregate makes each multi-entity command atomic.
// Observations, jobs, approvals and audit history live in the document and are
// independently addressable by stable IDs. No records are stored in localStorage.
export const workspaces = sqliteTable('workspaces', {
  ownerId: text('owner_id').primaryKey(),
  revision: integer('revision').notNull().default(0),
  document: text('document').notNull(),
  updatedAt: text('updated_at').notNull(),
  lastCommand: text('last_command'),
});
export const commands = sqliteTable('commands', {
  ownerId: text('owner_id').notNull(),
  key: text('command_key').notNull(),
  inputHash: text('input_hash').notNull(),
  result: text('result').notNull(),
  revision: integer('revision').notNull(),
  createdAt: text('created_at').notNull(),
}, (t) => [primaryKey({columns:[t.ownerId,t.key]})]);
// Large raw answers must not make the aggregate exceed a single SQLite row.
export const workspaceChunks = sqliteTable('workspace_chunks', {
  ownerId:text('owner_id').notNull(),
  snapshotId:text('snapshot_id').notNull(),
  chunkIndex:integer('chunk_index').notNull(),
  document:text('document').notNull(),
},(t)=>[primaryKey({columns:[t.ownerId,t.snapshotId,t.chunkIndex]})]);
